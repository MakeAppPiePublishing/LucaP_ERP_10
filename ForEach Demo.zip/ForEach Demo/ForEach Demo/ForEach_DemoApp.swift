//
//  ForEach_DemoApp.swift
//  ForEach Demo
//
//  Created by Steven Lipton on 7/11/25.
//

import SwiftUI

@main
struct ForEach_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
