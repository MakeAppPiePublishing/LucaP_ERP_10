//
//  ContentView.swift
//  ForEach Demo
//
//  Created by Steven Lipton on 7/11/25.
//

import SwiftUI

enum Role:String{
    case founder = "Founder"
    case vendor = "Vendor"
    case employee = "Employee"
    case customer = "Customer"
    case ohana = "Ohana"
    case regulator = "Regulator"
}

struct aRow:Identifiable{
    var name:String
    var id:Int
    var role:Role = .customer
}

@Observable class AModel{
    var table:[aRow] = []
    init(){
        table = [
            aRow(name:"Nova",id:0,role:.founder),
            aRow(name:"David",id:1,role:.founder),
            aRow(name:"Keiko",id:2,role:.founder),
            aRow(name:"George",id:3,role:.founder),
            aRow(name:"Craig",id:4,role:.vendor),
            aRow(name:"Carmen",id:5,role:.ohana),
            aRow(name:"Steve",id:6, role:.regulator),
            aRow(name:"Auntie Maise",id:7, role:.ohana),
            aRow(name:"Kai",id:8,role:.customer),
            aRow(name:"Jesse",id:9,role:.employee),
            aRow(name:"Sara",id:10,role:.employee),
            aRow(name:"Tia",id:11,role:.employee),
            aRow(name:"Ralph",id:12,role:.employee),
            aRow(name:"Jorge",id:13,role:.employee),
            aRow(name:"Mark",id:14,role:.employee)
            
        ]
    }
}


struct RoleDescriptor:Identifiable{
    var id:Role
    var description:String
}

class Roles{
    var roles:[RoleDescriptor] = [
        RoleDescriptor(id: .founder, description: "The original investors in HPC"),
        RoleDescriptor(id: .vendor, description: "People who we pay for goods and services(A/P)"),
        RoleDescriptor(id: .employee, description: "People we pay to work in our facilities"),
        RoleDescriptor(id: .ohana, description: "Friends and family"),
        RoleDescriptor(id: .regulator, description: "Local, State and Federal Government people. "),
        RoleDescriptor(id: .customer, description: "People who love our pizza so much, they give us money for it"),
        
    ]
}

struct ContentView: View {
    @State var aModel = AModel()
    @State var table = AModel().table
    @State var selected:Int! = nil
    @State var roles = Roles().roles
    @State var index:Int = 0
    
    
    var body: some View {
        VStack(alignment:.leading) {
            
            Text(roles[index].id.rawValue)
                .font(.largeTitle).bold()
            Text(roles[index].description)
            Divider()
            
            Text("Basic ForEach, all values").font(.title)
            ScrollView{
                ForEach(aModel.table.filter{$0.role == .founder}){row in
                    HStack{
                        Text(row.name)
                            .frame(width:150)
                        Text(row.role.rawValue).frame(width:150)
                        Spacer()
                    }
                }
            }
            .padding(.bottom,10)
            Text("Binding ForEach").font(.title)
            ScrollView{
                ForEach($aModel.table.filter{$row in row.role == roles[index].id}){$row in
                    Button{
                        selected = row.id
                    } label:{
                        HStack{
                            TextField("Name",text:$row.name).frame(width:150)
                            Text(row.role.rawValue).frame(width:150)
                            Spacer()
                        }
                        .background(.yellow.opacity(selected == row.id ? 1.0 : 0.01))
                    }
                }
            }
            .padding(.bottom,10)
            
        }
        .padding()
        Button("Next"){
            index = (index + 1) % roles.count
        }
        .font(.title)
        .buttonStyle(.borderedProminent)
        
    }
}

#Preview {
    ContentView()
}
